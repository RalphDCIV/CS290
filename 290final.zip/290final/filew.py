# Write to file i made to make sure python was working
with open('data.txt', 'w') as file:
    file.write('Hello, world!\n')
    file.write('This is a new line.')