const quizForm = document.getElementById('quiz-form');
const questionnumContainer = document.getElementById('questionnum');
const questionContainer = document.getElementById('question');
const optionsContainer = document.getElementById('options');
let currentQuestion = 1;
let score = 0;

const questions = [
    {
        questionNum: "Question: 0",
        question: "Template",
        options: ["1", "2", "3", "4"],
        answer: "1"
    },
    {
        questionNum: "Question: 1",
        question: "Which of the following nations did NOT partition Poland?",
        options: ["Prussia", "Austria", "Sweden", "Russia"],
        answer: "Sweden"
    },
    {
        questionNum: "Question: 2",
        question: "The Smoking Snakes were an Expeditionary force from what country during WW2?",
        options: ["Mexico", "Brazil", "Egypt", "India"],
        answer: "Brazil"
    },
    {
        questionNum: "Question: 3",
        question: "During the Angolan civil war, the war became a proxy war between what two countries?",
        options: ["USA and USSR", "USSR and Portugal", "South Africa and USSR", "Cuba and South Africa"],
        answer: "Cuba and South Africa"
    },
    {
        questionNum: "Question: 4",
        question: "Which of the following did NOT occur at the Battle of Schloss Itter during WW2?",
        options: ["A French Tennis player pissed on a tree to confuse SS soldiers.", "American soldiers, German soldiers, and an SS officer fought on the same side", 
        "The Battle took place in a medieval Castle turned hotel in Austria", "One of the American soldiers used a Sword during the battle."],
        answer: "One of the American soldiers used a Sword during the battle"
    },
    {
        questionNum: "Question: 5",
        question: "Which of the following did NOT have overseas colonies?",
        options: ["Belgium", "Sweden", "Netherlands", "Finland"],
        answer: "Finland"
    },
    {
        questionNum: "Question: 6",
        question: "What two European nations divided the world between them in the treaty of Tordesillas?",
        options: ["England and France", "Portugal and Spain", "Russia and UK", "Germany and UK"],
        answer: "Portugal and Spain"
    },
    {
        questionNum: "Question: 7",
        question: "Lauri Allan Torni is referred to as the soldier of 3 armies. What army did he NOT fight for?",
        options: ["USA", "Germany (Nazi)", "Finland", "USSR"],
        answer: "USSR"
    },
    {
        questionNum: "Question: 8",
        question: "What European country had its prime minister killed and eaten by an angry mob?",
        options: ["France", "Netherlands", "Russia", "Norway"],
        answer: "Netherlands"
    },
    {
        questionNum: "Question: 9",
        question: "Witold Pilecki was a hero of Poland during its occupation in WW2. The number 4859 refers to what about him?",
        options: ["The number of Nazis he killed during the war", "The number assigned to him in Auschwitz", "An important code used to help break the Enigma machine", "The number is unrelated"],
        answer: "The number assigned to him in Auschwitz"
    },
    {
        questionNum: "Question: 10",
        question: "The nation of Germany was largely unified by the nation of Prussia. Despite this, most of Prussia's historical land is no longer a part of Germany. True or False?",
        options: ["True", "False"],
        answer: "True"
    },
    {
        questionNum: "Question: 11",
        question: "The only nation in Africa to avoid European colonization was the kingdom of Ethiopia. True or False?",
        options: ["True", "False"],
        answer: "False"
    },
    {
        questionNum: "Question: 12",
        question: "When Napoleon returned from the island of Elba and reclaimed France, the European powers declared war not on France but on Napoleon himself. True or False?",
        options: ["True", "False"],
        answer: "True"
    },
    {
        questionNum: "Question: 13",
        question: "There are exactly 193 nations in the world. True or False?",
        options: ["True", "False"],
        answer: "False"
    },
    {
        questionNum: "Question: 14",
        question: "Before World War 1 Stalin and Hitler actually lived in the same city. This city was?",
        options: ["Paris", "Vienna", "Berlin", "Stockholm"],
        answer: "Vienna"
    },
    {
        questionNum: "Question: 15",
        question: "Which nation was NOT directly involved in the 30 years war?",
        options: ["Sweden", "Denmark", "England", "France"],
        answer: "England"
    },
    {
        questionNum: "Question: 16",
        question: "How many Carriers did the Japanese navy lose at Midway?",
        options: ["2", "3", "4", "5"],
        answer: "4"
    },    
    {
        questionNum: "Question: 17",
        question: "Who was the 6th nation to obtain nuclear weapons?",
        options: ["India", "China", "North Korea", "Pakistan"],
        answer: "India"
    },
    {
        questionNum: "Question: 18",
        question: "What nation had functioning nuclear weapons but got rid of them?",
        options: ["Ukraine", "South Africa", "Egypt", "Germany"],
        answer: "South Africa"
    },
    {
        questionNum: "Question: 19",
        question: "The biggest land empire in the world belonged to what nation?",
        options: ["Germany", "Persia", "Rome", "Mongolia"],
        answer: "Mongolia"
    },
    {
        questionNum: "Question: 20",
        question: "Which of the following was NOT something Teddy Roosevelt did?",
        options: ["Hunted a group of boat thieves by building a second boat", 
        "Fought in the Spanish American War", 
        "Went on a safari and trapped or killed 11,400 animals", 
        "Wanted to fight in WW1 but was told no by the acting president",
        "Was shot during a campaign speech and then continued the speech mocking the failed assassin",
        "Was born sickly but overcame it through sheer force of will",
        "Helped invent modern football",
        "Nearly died on an expedition in the Amazon after leaving office",
        "Fought corruption in the New York Police Department",
        "Became a cowboy after the deaths of his wife and mother",
        "Created more national parks than any other president",
        "Appointed black Americans to federal positions in a time where this was controversial",
        "ALL of these are true"
        ],
    
        answer: "ALL of these are true"
    }

];

function loadQuestion() { //sets up der questions
    const question = questions[currentQuestion];
    questionContainer.textContent = question.question;
    questionnumContainer.textContent = question.questionnum;
    
    optionsContainer.innerHTML = '';
    question.options.forEach((option, index) => {
        const radioBtn = document.createElement('input');
        radioBtn.type = 'radio';
        radioBtn.name = 'option';
        radioBtn.value = option;
        radioBtn.id = 'option' + index;

        const label = document.createElement('label');
        label.textContent = option;
        label.htmlFor = 'option' + index;

        optionsContainer.appendChild(radioBtn);
        optionsContainer.appendChild(label);
        optionsContainer.appendChild(document.createElement('br'));
    });
}

function checkAnswer() { //checks if you got the anwer correct and then if there is another question to load
    const selectedOption = document.querySelector('input[name="option"]:checked');
    let explanation = "";
    if (selectedOption && selectedOption.value === questions[currentQuestion].answer) {
        score++;
        alert("correct!");
    } else {
        alert("Wrong!");
    }
    currentQuestion++; 
    if (currentQuestion < questions.length) { //load the next question if there is a next question
        loadQuestion();
    } else { //
        alert(`Quiz completed! Your score is: ${score}`);
        window.location.href = "results.html"; // Change this URL to your desired webpage
    
    }
}


quizForm.addEventListener('submit', function (event) {
    event.preventDefault();

    // Check if any radio button is checked
    const selectedOption = document.querySelector('input[name="option"]:checked');
    if (!selectedOption) {
        alert('Please select an option');
        return; // Exit the function early if no option is selected
    }

    checkAnswer();
});

loadQuestion();