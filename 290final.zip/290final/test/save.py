from flask import Flask, render_template, request

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/save', methods=['POST'])
def save():
    data = request.form['data']
    file_path = 'data.txt'
    try:
        with open(file_path, 'w') as f:
            f.write(data)
        return 'Data saved successfully.'
    except Exception as e:
        return f'Error saving data: {e}'

if __name__ == '__main__':
    app.run(debug=True)