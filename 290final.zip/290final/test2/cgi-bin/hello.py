#!python3
import time
print("Content-type: text/html")
print()
print("<title>Test CGI</title>")
print("<p>Hello World</p>")
time.sleep(10)