#!python3

import cgi
import os

# Set the path to the directory where the files will be saved
file_directory = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))

# Set the path to the output file
output_file_path = os.path.join(file_directory, "output.txt")

# Read the form data
form = cgi.FieldStorage()

# Get the data from the form
data = form.getvalue('data')

# Write the data to the output file
with open(output_file_path, 'a') as f:
    f.write(data + "\n")

# Print a confirmation message
print("Content-type: text/html")
print()
print("<html><body>")
print("<h1>File written successfully!</h1>")
print("</body></html>")