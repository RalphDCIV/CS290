Assignment this week is the Quiz document
	Its a simple quiz to demostrate the javascript features,
	(Sorry for the late submision got sick over the weekend and wasnt abale to finish it on time.)